<?php

namespace UpdateHelper;

use InvalidArgumentException;

class NotUpdateInterfaceInstanceException extends InvalidArgumentException
{
}
